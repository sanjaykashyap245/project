﻿using PayrollManagementDal;
using PayrollManagementEntity;
using PayrollManagementException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollManagementBal
{
    public class CEmployeeBAL
    {
        //******************  Validation Section of all Data **********************//
        private static bool ValidateAddedEmployee(CEmployeeMaster employee)
        {
            StringBuilder sb = new StringBuilder();
            bool validEmployee = true;
            if (employee.Password == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Password Required");

            }
            if (employee.DOJ.ToString() == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Date Of Joining Required");

            }
            if (employee.FirstName == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "First Name Required");

            }
            if (employee.LastName == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Last Name Required");

            }
            if (employee.Address == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Address Required");

            }
            if (validEmployee == false)
                throw new CPayrollException(sb.ToString());
            return validEmployee;
        }

        //******************  End Here **********************//


        //******************  Add Employee BAL Method **********************//
        public static bool AddEmployeeBL(CEmployeeMaster newEmployee)
        {
            bool employeeAdded = false;
            try
            {
                if (ValidateAddedEmployee(newEmployee))
                {
                    CEmployeeDal employeeDAL = new CEmployeeDal();
                    employeeAdded = employeeDAL.AddEmployeeDAL(newEmployee);
                }
            }
            catch (CPayrollException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeAdded;
        }

        //*********************   End Here   *****************************//
    }
}

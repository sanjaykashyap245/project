﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollManagementEntity
{
    public class CPayrollDetails
    {
        public string EmployeeGrade { get; set; }
        public decimal Basic { get; set; }
        public decimal HRA { get; set; }
        public decimal DA { get; set; }
        public decimal PF { get; set; }
        public decimal NetSal { get; set; }
        public int TotalWorkingDays { get; set; }

        public string Designation { get; set; }
    }
}

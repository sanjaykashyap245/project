﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollManagementEntity
{
    class CLeaveDetails
    {
        public int EmployeeId { get; set; }
        public DateTime LeaveDate { get; set; }
        public DateTime ApplyDate { get; set; }
        public int LeaveDays { get; set; }
        public string Reason { get; set; }
        public string LeaveType { get; set; }
        public char LeaveStatus { get; set; }    //p for pending, d for declined,a for approved
    }
}

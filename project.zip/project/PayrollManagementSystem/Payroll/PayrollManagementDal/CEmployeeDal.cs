﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PayrollManagementException;
using PayrollManagementEntity;
using System.Data.Common;
using System.Data;

namespace PayrollManagementDal
{
    public class CEmployeeDal
    {

        //******************  ADDING EMPLOYEE USING Employee Master  ******************************//
        public bool AddEmployeeDAL(CEmployeeMaster newEmployee)
        {
            bool employeeAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "addemployee";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@password";
                param.DbType = DbType.String;
                param.Value = newEmployee.Password;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@doj";
                param.DbType = DbType.Date;
                param.Value = newEmployee.DOJ;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@firstname";
                param.DbType = DbType.String;
                param.Value = newEmployee.FirstName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@lastname";
                param.DbType = DbType.String;
                param.Value = newEmployee.LastName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@address";
                param.DbType = DbType.String;
                param.Value = newEmployee.Address;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    employeeAdded = true;
            }
            catch (CPayrollException ex)
            {
                //string errormessage;
                throw new CPayrollException(ex.Message);
            }
            return employeeAdded;
        }

        //**************************  End Method  *************************************//
    }
}

use PayrollManagementSystem;

go
create procedure populateDesignation 
as
begin
	select * from Payroll_Details;
end;

select * from Payroll_Details;

insert into Payroll_Details values('A4',12000.00,4500.00,500.00,1000.00,16000.00,2.4,'Analyst'); 

go
create procedure populateGrade @desig varchar(30) as
begin
	select Employee_Grade from Payroll_Details where Designation=@desig;
end;



sp_helptext addemployee;
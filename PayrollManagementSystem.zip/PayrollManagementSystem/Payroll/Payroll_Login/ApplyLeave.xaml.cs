﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PayrollManagementBal;
using PayrollManagementException;
using PayrollManagementEntity;


namespace Payroll_Login
{
    /// <summary>
    /// Interaction logic for ApplyLeave.xaml
    /// </summary>
    public partial class ApplyLeave : Window
    {
        static int empid=114;
        static string firstname;
        static string lastname;
        static double diff;
        public ApplyLeave()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //empid = 114;
            firstname = "Gaurav";
            lastname = "Ghosh";
            txt_LeaveEmployeeid.Text = firstname + " " + lastname + "(" + empid + ")";

            
            cmb_Leave.Items.Add("Casual");
            cmb_Leave.Items.Add("Sick");
            cmb_Leave.Items.Add("Priviledge");
            cmb_Leave.Items.Add("Comp-Off");
            cmb_Leave.Items.Add("Relocation Leave");
            cmb_Leave.SelectedIndex = 0;


            List<CLeaveMaster> listLeave = null;
            listLeave = CEmployeeBAL.mGetLeaveDetailsBAL(empid);

            foreach (var item in listLeave)
            {
                lbl_CurrentLeaveBalance.Content = item.LeavesBalance+" Day(s)";
            }

            start_date.DisplayDateStart = DateTime.Now;

        }

        private void end_date_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            DateTime startdate = start_date.SelectedDate.Value;
            DateTime enddate = end_date.SelectedDate.Value;
            //MessageBox.Show(startdate.ToString());
            //MessageBox.Show(enddate.ToString());

            //DateTime start = start_date.SelectedDate.Value;
            double d=startdate.ToOADate();
            double f = enddate.ToOADate();
            diff = f - d;
            lbl_LeaveTaken.Content = diff.ToString()+" Day(s)";
            
            
        }

        private void start_date_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            end_date.DisplayDateStart = start_date.SelectedDate;
        }

        private void btn_SubmitLeave_Click(object sender, RoutedEventArgs e)
        {
            bool leaveadded = false;
            CLeaveDetails empLeave = new CLeaveDetails();
            empLeave.EmployeeId = empid;
            empLeave.ApplyDate =Convert.ToDateTime(start_date.SelectedDate.ToString());
            empLeave.LeaveDate = Convert.ToDateTime(end_date.SelectedDate.ToString());
            empLeave.LeaveDays = Convert.ToInt32(diff);
            empLeave.Reason = txt_Reason.Text;
            empLeave.LeaveType = cmb_Leave.Text;
            
            try
            {
                leaveadded = CEmployeeBAL.mLeaveAddedBAL(empLeave);
            }
            catch (CPayrollException)
            {

                throw;
            }
            if (leaveadded == true)
            {
                MessageBox.Show("Leave Application submitted");
            }
            else
            {
                MessageBox.Show("Couldn't submit.Please try Again");
            }
        }
    }
}

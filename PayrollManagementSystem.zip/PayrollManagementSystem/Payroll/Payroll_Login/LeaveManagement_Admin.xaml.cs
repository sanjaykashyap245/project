﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Payroll_Login
{
    /// <summary>
    /// Interaction logic for LeaveManagement_Admin.xaml
    /// </summary>
    public partial class LeaveManagement_Admin : Window
    {
        public LeaveManagement_Admin()
        {
            InitializeComponent();
        }
    }
}

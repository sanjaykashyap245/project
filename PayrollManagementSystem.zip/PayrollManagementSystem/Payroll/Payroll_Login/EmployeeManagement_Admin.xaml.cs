﻿using PayrollManagementBal;
using PayrollManagementEntity;
using PayrollManagementException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Payroll_Login
{
    /// <summary>
    /// Interaction logic for EmployeeManagement_Admin.xaml
    /// </summary>
    public partial class EmployeeManagement_Admin : Window
    {
        static List<CPayrollDetails> listobj = null;               //Payroll Details List Initialized

        static List<CshowAllEmployee_Admin> listEmployee = null;  //Show All Employee List Initialized

        public EmployeeManagement_Admin()
        {
            InitializeComponent();
        }

        //******************** Adding Employee  *******************// 
        private void btnadd_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                // MessageBox.Show(id.ToString());

                CEmployeeMaster newEmployee = new CEmployeeMaster();
                newEmployee.FirstName = txtfname.Text;
                newEmployee.LastName = txtlname.Text;
                newEmployee.DOJ = Convert.ToDateTime(doj.Text);
                newEmployee.Address = txtaddr.Text;
                newEmployee.Password = txtpwd.Password.ToString();

                CPayrollMaster newPayroll = new CPayrollMaster();
                newPayroll.Designation = cmb_designation.SelectedItem.ToString();
                newPayroll.Grade = cmb_Grade.SelectedItem.ToString();
                newPayroll.EmployeeID = Convert.ToInt32(txtid.Text);

                bool status = CEmployeeBAL.AddEmployeeBL(newEmployee);



                bool payrolladded = CEmployeeBAL.mAddPayrollMasterBAL(newPayroll);

                if (status && payrolladded)
                {
                    MessageBox.Show("Employee Added");          //When data is added correctly
                    txtfname.Text = "";
                    txtlname.Text = "";
                    doj.Text = "";
                    txtaddr.Text = "";
                    txtpwd.Password = "";

                    int id = 0;
                    id = CEmployeeBAL.mgetEmployeeIDBAL();
                    txtid.Text = id.ToString();
                    mgetAllEmployee();                 //Data Grid Populate Details
                }
                else
                {
                    MessageBox.Show("Employee Not added");
                }
            }
            catch (Exception ex)
            {
                throw new CPayrollException(ex.ToString());
            }
        }

        //************************  End Add Employee ******************//

        //********************* Window Load Event *********************//
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtid.IsEnabled = false;
            int id = 0;
            try
            {
                listobj = new List<CPayrollDetails>();
                listobj = CEmployeeBAL.mPopulateDesignationBAL();
                foreach (var item in listobj)
                {
                    if (cmb_designation.Items.Contains(item.Designation) == false)
                        cmb_designation.Items.Add(item.Designation);
                }

                id = CEmployeeBAL.mgetEmployeeIDBAL();
                // MessageBox.Show(id.ToString());
                txtid.Text = id.ToString();

                mgetAllEmployee();

            }
            catch (Exception ex)
            {
                throw new CPayrollException(ex.ToString());
            }
        }

        //******************** End Window Load Event *********************//

        //********************* Get All Employee Method *****************//
        private void mgetAllEmployee()
        {
            try
            {
                listEmployee = new List<CshowAllEmployee_Admin>();
                listEmployee = CEmployeeBAL.mgetAllEmployeeMasterBAL();

                dgEmployee.ItemsSource = listEmployee;
            }
            catch (CPayrollException)
            {
                throw;
            }
        }

        //******************** End Get All Employee Method *********************//

        //***************  ComboBox Designation Selection Event   *****************//
        private void cmb_designation_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cmb_Grade.Items.Clear();
            List<string> listobj = null;
            try
            {
                listobj = CEmployeeBAL.mPopulateGradeBAL(cmb_designation.SelectedItem.ToString());
                foreach (var item in listobj)
                {
                    cmb_Grade.Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                throw new CPayrollException(ex.ToString());
            }
        }

        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
            int employeeid;
            List<CshowAllEmployee_Admin> listEmployeeobj = null;
            try
            {

                listobj = new List<CPayrollDetails>();
                listobj = CEmployeeBAL.mPopulateDesignationBAL();
                foreach (var item in listobj)
                {
                    if (cmb_DesignationUpdateDelete.Items.Contains(item.Designation) == false)
                        cmb_DesignationUpdateDelete.Items.Add(item.Designation);
                }


                employeeid = Convert.ToInt32(txt_IDUpdateDelete.Text);
                listEmployeeobj = CEmployeeBAL.mShowEmployeeDetailsBAL(employeeid);

                foreach(var item in listEmployeeobj)
                {
                    cmb_DesignationUpdateDelete.SelectedItem = item.Designation;
                    cmb_GradeUpdateDelete.Items.Add(item.Grade);
                    cmb_GradeUpdateDelete.SelectedItem = item.Grade;
                }
            }
            catch (CPayrollException ex)
            {
                throw;
            }
        }

        private void cmb_DesignationUpdateDelete_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (txt_IDUpdateDelete.Text=="")
            {
                cmb_DesignationUpdateDelete.Text = null;
            }

            else{
                cmb_GradeUpdateDelete.Items.Clear();
                List<string> listgrade = null;
                try
                {
                    listgrade = CEmployeeBAL.mPopulateGradeBAL(cmb_DesignationUpdateDelete.SelectedItem.ToString());
                    foreach (var item in listgrade)
                    {
                        cmb_GradeUpdateDelete.Items.Add(item);
                    }
                }
                catch (Exception ex)
                {
                    throw new CPayrollException(ex.ToString());
                }
            }
        }

        private void btn_Update_Click(object sender, RoutedEventArgs e)
        {

            CPayrollMaster payrollobj = new CPayrollMaster();
            bool payrollUpdated = false;
            payrollobj.EmployeeID =Convert.ToInt32(txt_IDUpdateDelete.Text);
            payrollobj.Designation = cmb_DesignationUpdateDelete.SelectedItem.ToString();
            payrollobj.Grade = cmb_GradeUpdateDelete.SelectedItem.ToString();
            try
            {
                payrollUpdated = CEmployeeBAL.mUpdatePayrollMasterBAL(payrollobj);

                if (payrollUpdated == true)
                {
                    MessageBox.Show("Updated");
                    mgetAllEmployee();
                }
                else
                {
                    MessageBox.Show("Update Failed");
                }
            }
            catch (CPayrollException)
            {
                throw;
            }
        }

        private void btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            int employeeID;
            bool employeeDeleted = false;
            employeeID = Convert.ToInt32(txt_IDUpdateDelete.Text);

            try
            {
                employeeDeleted = CEmployeeBAL.mDeleteEmployeeMasterBAL(employeeID);

                if (employeeDeleted == true)
                {
                    MessageBox.Show("Deleted");
                    txt_IDUpdateDelete.Text = "";
                    cmb_DesignationUpdateDelete.Text = null;
                    cmb_GradeUpdateDelete.Text = null;
                    mgetAllEmployee();
                }
                else
                {
                    MessageBox.Show("Delete Failed");
                }
            }
            catch (CPayrollException)
            {

                throw;
            }
        }


        //******************** End ComboBox Designation Selection Event  *********************//
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollManagementEntity
{
    public class CshowAllEmployee_Admin
    {
        public int EmployeeID { get; set; }          
        public DateTime DOJ { get; set; }
        public string EmployeeFirstName { get; set; }
        public string EmployeeLastName { get; set; }
        public string Designation { get; set; }
        public string Grade { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollManagementEntity
{
    class CTimeSheet
    {
        public int EmployeeID { get; set; }
        public int TimeSheetID { get; set; }
        public string EmployeeActivity { get; set; }
        public decimal NumberOfHoursSpent { get; set; }
        public decimal TotalHoursPerDay { get; set; }
        public char Status { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PayrollManagementException;
using PayrollManagementEntity;
using System.Data.Common;
using System.Data;
using System.Windows;

namespace PayrollManagementDal
{
    public class CEmployeeDal
    {

        //******************  ADDING EMPLOYEE USING Employee Master  ******************************//
        public bool AddEmployeeDAL(CEmployeeMaster newEmployee)
        {
            bool employeeAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "addemployee";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@password";
                param.DbType = DbType.String;
                param.Value = newEmployee.Password;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@doj";
                param.DbType = DbType.Date;
                param.Value = newEmployee.DOJ;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@firstname";
                param.DbType = DbType.String;
                param.Value = newEmployee.FirstName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@lastname";
                param.DbType = DbType.String;
                param.Value = newEmployee.LastName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@address";
                param.DbType = DbType.String;
                param.Value = newEmployee.Address;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    employeeAdded = true;
            }
            catch (CPayrollException ex)
            {
                //string errormessage;
                throw new CPayrollException(ex.Message);
            }
            return employeeAdded;
        }

        //**************************  End Method  *************************************//


        //******************  Designation data for Combo Box ****************************//
        public List<CPayrollDetails> mPopulateDesignationDAL()
        {
            List<CPayrollDetails> listobj = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "populateDesignation";

                DataTable table = DataConnection.ExecuteSelectCommand(command);
                if (table.Rows.Count > 0)
                {
                    listobj = new List<CPayrollDetails>();

                    for(int rowcounter = 0; rowcounter < table.Rows.Count; rowcounter++)
                    {
                        CPayrollDetails obj = new CPayrollDetails();
                        obj.EmployeeGrade = (string)table.Rows[rowcounter][0];
                        obj.Basic = (decimal)table.Rows[rowcounter][1];
                        obj.HRA = (decimal)table.Rows[rowcounter][2];
                        obj.DA = (decimal)table.Rows[rowcounter][3];
                        obj.PF = (decimal)table.Rows[rowcounter][4];
                        obj.NetSal = (decimal)table.Rows[rowcounter][5];
                        obj.TotalWorkingDays = (decimal)table.Rows[rowcounter][6];
                        obj.Designation = (string)table.Rows[rowcounter][7];

                        listobj.Add(obj);
                    }
                }
            }
            catch(Exception ex)
            {
                throw new CPayrollException(ex.ToString());
            }
            return listobj;
        }

        //******************  End Here **********************//

        //******************  Grade Data for Combo Box **********************//
        public List<string> mPopulateGradeDAL(string designation)
        {
            List < string > listobj= null;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "populateGrade";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@desig";
                param.DbType = DbType.String;
                param.Value = designation;
                command.Parameters.Add(param);

                DataTable datatable = DataConnection.ExecuteSelectCommand(command);
                if (datatable.Rows.Count>0)
                {
                    listobj = new List<string>();
                    for (int rowcounter = 0; rowcounter < datatable.Rows.Count; rowcounter++)
                    {

                        string grade = null;
                        grade = (string)datatable.Rows[rowcounter][0];
                        listobj.Add(grade);
                    }
                }
            }
            catch(Exception ex)
            {
                throw new CPayrollException(ex.ToString());
            }

            return listobj;
        }

        //******************  End Here **********************//

        //******************  Get All Employee Data **********************//
        public int mgetEmployeeIDDAL()
        {
            int id = 0;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "getEmployeeID";

                id =Convert.ToInt32(DataConnection.ExecuteScalarCommand(command));
            }
            catch(Exception ex)
            {
                throw new CPayrollException(ex.ToString());
            }
            return id;
        }

        //******************  End Here **********************//

        //******************  Get Payroll Details by Grade  **********************//
        public bool mAddPayrollMasterDAL(CPayrollMaster newPayroll)
        {

            //METHOD TO ADD RECORD IN TABLE USING EMPLOYEEID

            bool payrollAdded = false;
            //List<CPayrollDetails> templist = null;
            decimal salary=0;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "getPayrollDetailsbyGrade";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@grade";
                param.DbType = DbType.String;
                param.Value = newPayroll.Grade;
                command.Parameters.Add(param);

                DataTable datatable = DataConnection.ExecuteSelectCommand(command);
                if (datatable.Rows.Count > 0)
                {
                    CPayrollDetails tempobj = new CPayrollDetails();
                    tempobj.Basic =(decimal) datatable.Rows[0][1];
                    tempobj.DA= (decimal)datatable.Rows[0][3];
                    tempobj.HRA= (decimal)datatable.Rows[0][2];
                    tempobj.PF= (decimal)datatable.Rows[0][4];

                    salary = tempobj.Basic + tempobj.DA + tempobj.HRA - tempobj.PF;
                }

                newPayroll.Salary = salary;

                DbCommand command2 = DataConnection.CreateCommand();
                command2.CommandText = "addPayrollMaster";

                DbParameter param2 = command2.CreateParameter();
                param2.ParameterName = "@id";
                param2.DbType = DbType.Int32;
                param2.Value = newPayroll.EmployeeID;
                command2.Parameters.Add(param2);

                param2 = command2.CreateParameter();
                param2.ParameterName = "@desig";
                param2.DbType = DbType.String;
                param2.Value = newPayroll.Designation;
                command2.Parameters.Add(param2);

                param2 = command2.CreateParameter();
                param2.ParameterName = "@grade";
                param2.DbType = DbType.String;
                param2.Value = newPayroll.Grade;
                command2.Parameters.Add(param2);

                param2 = command2.CreateParameter();
                param2.ParameterName = "@salary";
                param2.DbType = DbType.Decimal;
                param2.Value = newPayroll.Salary;
                command2.Parameters.Add(param2);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command2);

                DbCommand command3 = DataConnection.CreateCommand();
                command3.CommandText = "addLeaveMaster";

                DbParameter param3 = command3.CreateParameter();
                param3.ParameterName = "@id";
                param3.DbType = DbType.Int32;
                param3.Value = newPayroll.EmployeeID;
                command3.Parameters.Add(param3);

                int affectedRowsLeaveMaster = DataConnection.ExecuteNonQueryCommand(command3);

                if (affectedRows > 0 && affectedRowsLeaveMaster>0)
                        payrollAdded = true;
            }
            catch(CPayrollException ex)
            {
                throw new CPayrollException(ex.ToString());
            }
            return payrollAdded;
        }

        //******************  End Here **********************//

        //******************  Employee Master Details **********************//
        public List<CshowAllEmployee_Admin> mgetAllEmployeeMasterDAL()
        {
            List<CshowAllEmployee_Admin> listEmployee = null;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "getAllEmployeeMaster";

                DataTable datatable = DataConnection.ExecuteSelectCommand(command);
                if (datatable.Rows.Count > 0)
                {
                    listEmployee = new List<CshowAllEmployee_Admin>();

                    for (int rowcounter = 0; rowcounter < datatable.Rows.Count; rowcounter++)
                    {
                        CshowAllEmployee_Admin tempobj = new CshowAllEmployee_Admin();
                        tempobj.EmployeeID = (int)datatable.Rows[rowcounter][0];
                        tempobj.DOJ = (DateTime)datatable.Rows[rowcounter][1];
                        tempobj.EmployeeFirstName = (string)datatable.Rows[rowcounter][2];
                        tempobj.EmployeeLastName = (string)datatable.Rows[rowcounter][3];
                        tempobj.Designation = (string)datatable.Rows[rowcounter][4];
                        tempobj.Grade = (string)datatable.Rows[rowcounter][5];

                        listEmployee.Add(tempobj);
                    }
                }
            }
            catch (CPayrollException ex)
            {
                throw;
            }
            return listEmployee;
        }

        //******************  End Here **********************//


        public List<CshowAllEmployee_Admin> mShowEmployeeDetailsDAL(int employeeid)
        {
            List<CshowAllEmployee_Admin> listobj = null;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "searchEmployeebyID";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@id";
                param.DbType = DbType.Int32;
                param.Value = employeeid;
                command.Parameters.Add(param);

                DataTable datatable = DataConnection.ExecuteSelectCommand(command);
                if (datatable.Rows.Count > 0)
                {
                    listobj = new List<CshowAllEmployee_Admin>();

                    CshowAllEmployee_Admin obj = new CshowAllEmployee_Admin();
                    obj.Designation =(string) datatable.Rows[0][4];
                    obj.Grade = (string)datatable.Rows[0][5];

                    listobj.Add(obj);
                }

            }
            catch (CPayrollException ex)
            {
                throw;
            }

            return listobj;
        }

        public bool mUpdatePayrollMasterDAL(CPayrollMaster payrollObj)
        {
            bool payrollUpdated = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "updatepayrollmaster";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@id";
                param.DbType = DbType.Int32;
                param.Value = payrollObj.EmployeeID;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@designation";
                param.DbType = DbType.String;
                param.Value = payrollObj.Designation;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@grade";
                param.DbType = DbType.String;
                param.Value = payrollObj.Grade;
                command.Parameters.Add(param);

                int affectedrows = DataConnection.ExecuteNonQueryCommand(command);
                if (affectedrows > 0)
                {
                    payrollUpdated = true;
                }
            }
            catch (CPayrollException)
            {
                throw;
            }
            return payrollUpdated;
        }

        public bool mDeleteEmployeeMasterDAL(int employeeID)
        {
            bool employeeDeleted = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "deleteEmployeeMaster";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@id";
                param.DbType = DbType.Int32;
                param.Value = employeeID;
                command.Parameters.Add(param);

                int affectedrows = DataConnection.ExecuteNonQueryCommand(command);
                if (affectedrows > 0)
                {
                    employeeDeleted = true;
                }
                else
                {
                    employeeDeleted = false;
                }
            }
            catch (CPayrollException)
            {

                throw;
            }
            return employeeDeleted;
        }


        public List<CLeaveMaster> mGetLeaveDetailsDAL(int employeeid)
        {
            List<CLeaveMaster> listLeave = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "getLeaveDetails";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@employeeid";
                param.DbType = DbType.Int32;
                param.Value = employeeid;
                command.Parameters.Add(param);

                DataTable datatable = DataConnection.ExecuteSelectCommand(command);
                if (datatable.Rows.Count > 0)
                {
                    listLeave = new List<CLeaveMaster>();
                    
                    CLeaveMaster leaveobj = new CLeaveMaster();
                    leaveobj.EmployeeID =(int) datatable.Rows[0][0];
                    leaveobj.LeaveAvailable=(int)datatable.Rows[0][1];
                    leaveobj.LeavesAvailed=(int)datatable.Rows[0][2];
                    leaveobj.LeavesBalance=(int)datatable.Rows[0][3];

                    listLeave.Add(leaveobj);
                }

            }
            catch (CPayrollException)
            {

                throw;
            }
            return listLeave;
        }


        public bool mLeaveAddedDAL(CLeaveDetails empLeave)
        {
            bool leaveadded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "applyLeave";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@empid";
                param.DbType = DbType.Int32;
                param.Value = empLeave.EmployeeId;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@start";
                param.DbType = DbType.Date;
                param.Value = empLeave.ApplyDate;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@end";
                param.DbType = DbType.Date;
                param.Value = empLeave.LeaveDate;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@days";
                param.DbType = DbType.Int32;
                param.Value = empLeave.LeaveDays;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@reason";
                param.DbType = DbType.String;
                param.Value = empLeave.Reason;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@type";
                param.DbType = DbType.String;
                param.Value = empLeave.LeaveType;
                command.Parameters.Add(param);

                int affectedrows = DataConnection.ExecuteNonQueryCommand(command);
                if (affectedrows > 0)
                {
                    leaveadded = true;
                }
            }
            catch (CPayrollException)
            {

                throw;
            }
            return leaveadded;
        }

        public List<CEmployeeMaster> mGetEmployeeDetailsbyIDDAL(int empid)
        {
            List<CEmployeeMaster> emplist = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "getEmployeeDetailsbyID";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@empid";
                param.DbType = DbType.Int32;
                param.Value = empid;
                command.Parameters.Add(param);

                DataTable datatable = DataConnection.ExecuteSelectCommand(command);
                if (datatable.Rows.Count > 0)
                {
                    emplist = new List<CEmployeeMaster>();
                    CEmployeeMaster empobj = new CEmployeeMaster();
                    empobj.Password =(string) datatable.Rows[0][1];
                    empobj.DOJ = Convert.ToDateTime(datatable.Rows[0][2]);
                    empobj.FirstName = (string)datatable.Rows[0][3];
                    empobj.LastName = (string)datatable.Rows[0][4];
                    empobj.Address = (string)datatable.Rows[0][5];

                    emplist.Add(empobj);
                }


            }
            catch (CPayrollException ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return emplist;
        }

    }
}

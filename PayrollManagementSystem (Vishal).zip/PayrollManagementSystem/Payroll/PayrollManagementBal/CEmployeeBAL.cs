﻿using PayrollManagementDal;
using PayrollManagementEntity;
using PayrollManagementException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PayrollManagementBal
{
    public class CEmployeeBAL
    {
        //******************  Validation Section of all Data **********************//
        private static bool ValidateAddedEmployee(CEmployeeMaster employee)
        {
            StringBuilder sb = new StringBuilder();
            bool validEmployee = true;
            if (employee.Password.Length < 10)    //Password Length Validation
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Password Length should be of 10 characters");
            }
            if (employee.Password == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Password Required");

            }
            if (employee.DOJ.ToString() == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Date Of Joining Required");

            }
            if (employee.FirstName == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "First Name Required");

            }
            if (employee.LastName == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Last Name Required");

            }
            if (employee.Address == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Address Required");

            }
            if (validEmployee == false)
                throw new CPayrollException(sb.ToString());
            return validEmployee;
        }

        //******************  End Here **********************//


        //******************  Add Employee BAL Method **********************//
        public static bool AddEmployeeBL(CEmployeeMaster newEmployee)
        {
            bool employeeAdded = false;
            try
            {
                if (ValidateAddedEmployee(newEmployee))
                {
                    CEmployeeDal employeeDAL = new CEmployeeDal();
                    employeeAdded = employeeDAL.AddEmployeeDAL(newEmployee);
                }
            }
            catch (CPayrollException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeAdded;
        }

        //*********************   End Here   *****************************//


        //******************  ComboBox - Designation Method **********************//
        public static List<CPayrollDetails> mPopulateDesignationBAL()
        {
            List<CPayrollDetails> listobj = null;
            try
            {
                CEmployeeDal obj = new CEmployeeDal();
                listobj=obj.mPopulateDesignationDAL();
            }
            catch(Exception ex)
            {
                throw new CPayrollException(ex.ToString());
            }
            return listobj;
        }

        //******************  End Here **********************//

        //******************  Grade Populate Method **********************//
        public static List<string> mPopulateGradeBAL(string designation)
        {
            List<string> listobj = null;
            try
            {
                CEmployeeDal obj = new CEmployeeDal();
                listobj=obj.mPopulateGradeDAL(designation);
            }
            catch(Exception ex)
            {
                throw new CPayrollException(ex.ToString());
            }
            return listobj;
        }

        //******************  End Here **********************//

        //******************  Get Employee ID Method **********************//
        public static int mgetEmployeeIDBAL()
        {
            int id=0;
            try
            {
                CEmployeeDal obj = new CEmployeeDal();
                id = obj.mgetEmployeeIDDAL();
            }
            catch(Exception ex)
            {
                throw new CPayrollException(ex.ToString());
            }
            return id;
        }

        //******************  End Here **********************//

        //******************  Payroll Master Adding Employee **********************//
        public static bool mAddPayrollMasterBAL(CPayrollMaster newPayroll)
        {
            bool payrolladded = false;
            try
            {
                CEmployeeDal obj = new CEmployeeDal();
                payrolladded=obj.mAddPayrollMasterDAL(newPayroll);
            }
            catch(Exception ex)
            {
                throw new CPayrollException(ex.ToString());
            }
            return payrolladded;
        }

        //******************  End Here **********************//

        //******************  Show All Employee Data for Gird **********************//
        public static List<CshowAllEmployee_Admin> mgetAllEmployeeMasterBAL()
        {
            List<CshowAllEmployee_Admin> listobj = null;
            try
            {
                CEmployeeDal obj = new CEmployeeDal();
                listobj = obj.mgetAllEmployeeMasterDAL();
            }
            catch (CPayrollException ex)
            {

                throw;
            }
            return listobj;
        }

        //******************  End Here **********************//


        public static List<CshowAllEmployee_Admin> mShowEmployeeDetailsBAL(int employeeid)
        {
            List<CshowAllEmployee_Admin> listobj = null;
            try
            {
                CEmployeeDal obj = new CEmployeeDal();
                listobj = obj.mShowEmployeeDetailsDAL(employeeid);
            }
            catch (CPayrollException ex)
            {
                throw;
            }
            return listobj;
        }

        public static bool mUpdatePayrollMasterBAL(CPayrollMaster payrollObj)
        {
            bool payrollUpdated = false;
            try
            {
                CEmployeeDal obj = new CEmployeeDal();
                payrollUpdated = obj.mUpdatePayrollMasterDAL(payrollObj);
            }
            catch (CPayrollException)
            {

                throw;
            }
            return payrollUpdated;
        }

        public static bool mDeleteEmployeeMasterBAL(int employeeID)
        {
            bool employeeDeleted = false;
            try
            {
                CEmployeeDal obj = new CEmployeeDal();
                employeeDeleted = obj.mDeleteEmployeeMasterDAL(employeeID);
            }
            catch (CPayrollException)
            {

                throw;
            }
            return employeeDeleted;
        }


        public static List<CLeaveMaster> mGetLeaveDetailsBAL(int employeeid)
        {
            List<CLeaveMaster> listLeave = null;
            try
            {
                CEmployeeDal obj = new CEmployeeDal();
                listLeave=obj.mGetLeaveDetailsDAL(employeeid);
            }
            catch (CPayrollException)
            {
                throw;
            }
            return listLeave;
        }

        public static bool mLeaveAddedBAL(CLeaveDetails empLeave)
        {
            bool leaveadded = false;
            try
            {
                CEmployeeDal obj = new CEmployeeDal();
                leaveadded=obj.mLeaveAddedDAL(empLeave);
            }
            catch (CPayrollException)
            {
                throw;
            }
            return leaveadded;
        }


        public static List<CEmployeeMaster> mGetEmployeeDetailsbyIDBAL(int empid)
        {
            List<CEmployeeMaster> listobj = null;
            try
            {
                CEmployeeDal obj = new CEmployeeDal();
                listobj = obj.mGetEmployeeDetailsbyIDDAL(empid);
            }
            catch (CPayrollException ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return listobj;
        }

        //========= Vishal 29/12/2017 ======//
        public static List<CLeaveDetails> mGetAllLeaveDetailsByStatusBAL(string status)
        {
            List<CLeaveDetails> listobj = null;
            try
            {
                CEmployeeDal obj = new CEmployeeDal();
                listobj = obj.mGetAllLeaveDetailsByStatusDAL(status);
            }
            catch (CPayrollException ex)
            {

                MessageBox.Show(ex.ToString());
            }
            return listobj;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PayrollManagementBal;
using PayrollManagementEntity;
using PayrollManagementException;

namespace Payroll_Login
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Window
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            int userid=Convert.ToInt32(txt_UserName.Text);
            List<CEmployeeMaster> emplist = null;
            try
            {
                emplist = CEmployeeBAL.mGetEmployeeDetailsbyIDBAL(userid);
                if (txt_Password.Text == emplist[0].Password)
                {
                    MessageBox.Show("Login Success!!");
                    
                }
                else
                {
                    MessageBox.Show("Login Failed!!");
                }
            }
            catch (CPayrollException ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }
    }
}

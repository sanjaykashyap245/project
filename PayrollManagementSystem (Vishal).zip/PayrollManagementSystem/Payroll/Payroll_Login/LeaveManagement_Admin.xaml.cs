﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PayrollManagementEntity;
using PayrollManagementException;
using PayrollManagementBal;

namespace Payroll_Login
{
    /// <summary>
    /// Interaction logic for LeaveManagement_Admin.xaml
    /// </summary>
    public partial class LeaveManagement_Admin : Window
    {
        static List<CLeaveDetails> listLeaveDetails = null;
        public LeaveManagement_Admin()
        {
            InitializeComponent();
        }

        private void mgetAllLeaveDetailsByStatus_P()
        {
            try
            {
                listLeaveDetails = new List<CLeaveDetails>();
                listLeaveDetails = CEmployeeBAL.mGetAllLeaveDetailsByStatusBAL("P");

                dataGridStatusPending.ItemsSource = listLeaveDetails;
            }
            catch (CPayrollException)
            {
                throw;
            }
        }
    
        private void mgetAllLeaveDetailsByStatus_A()
        {
            try
            {
                listLeaveDetails = new List<CLeaveDetails>();
                listLeaveDetails = CEmployeeBAL.mGetAllLeaveDetailsByStatusBAL("A");
                dataGridApprovedStatus.ItemsSource = listLeaveDetails;
            }
            catch (CPayrollException)
            {
                throw;
            }
        }

        private void mgetAllLeaveDetailsByStatus_D()
        {
            try
            {
                listLeaveDetails = new List<CLeaveDetails>();
                listLeaveDetails = CEmployeeBAL.mGetAllLeaveDetailsByStatusBAL("D");
                dataGridDeclinedStatus.ItemsSource = listLeaveDetails;
            }
            catch (CPayrollException)
            {
                throw;
            }
        }
        private void Leave_Window_Loaded(object sender, RoutedEventArgs e)
        {
            mgetAllLeaveDetailsByStatus_P();
            mgetAllLeaveDetailsByStatus_A();
            mgetAllLeaveDetailsByStatus_D();
        }

        private void btnResponse_Click(object sender, RoutedEventArgs e)
        {

            mgetAllLeaveDetailsByStatus_P();
            mgetAllLeaveDetailsByStatus_A();
            mgetAllLeaveDetailsByStatus_D();
        }

        private void btnPending_Click(object sender, RoutedEventArgs e)
        {
            mgetAllLeaveDetailsByStatus_P();
            mgetAllLeaveDetailsByStatus_A();
            mgetAllLeaveDetailsByStatus_D();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace PayrollManagementDal
{
    class PayrollConfiguration
    {
        private static string providerName;

        public static string ProviderName
        {
            get { return PayrollConfiguration.providerName; }
            set { PayrollConfiguration.providerName = value; }
        }
        private static string connectionString;

        public static string ConnectionString
        {
            get { return PayrollConfiguration.connectionString; }
            set { PayrollConfiguration.connectionString = value; }
        }

        static PayrollConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["PayrollConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["PayrollConnection"].ConnectionString;
        }
    }
}
